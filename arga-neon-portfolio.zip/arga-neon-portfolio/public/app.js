const $ = (s) => document.querySelector(s);
const nav = $('#nav');
$('#menuToggle').addEventListener('click', () => nav.classList.toggle('open'));
nav.querySelectorAll('a').forEach(a => a.addEventListener('click', () => nav.classList.remove('open')));

const modal = $('#authModal');
const authForm = $('#authForm');
const authStatus = $('#authStatus');
let authMode = 'login';
let token = localStorage.getItem('arga_token') || '';

function showModal() { modal.classList.add('show'); modal.setAttribute('aria-hidden','false'); }
function hideModal() { modal.classList.remove('show'); modal.setAttribute('aria-hidden','true'); }
$('#openAuth').addEventListener('click', showModal);
$('#closeAuth').addEventListener('click', hideModal);
modal.addEventListener('click', e => { if (e.target === modal) hideModal(); });
document.addEventListener('keydown', e => { if (e.key === 'Escape') hideModal(); });

function setMode(mode) {
  authMode = mode;
  document.querySelectorAll('.auth-tabs button').forEach(b => b.classList.toggle('active', b.dataset.mode === mode));
  $('#authTitle').innerHTML = mode === 'login' ? 'WELCOME <span>BACK.</span>' : 'CREATE <span>ACCOUNT.</span>';
  $('#nameWrap').classList.toggle('hidden', mode === 'login');
  $('#nameWrap input').required = mode === 'register';
  $('#authSubmit').textContent = mode === 'login' ? 'LOGIN ↗' : 'CREATE ACCOUNT ↗';
  authStatus.textContent = '';
}
document.querySelectorAll('.auth-tabs button').forEach(b => b.addEventListener('click', () => setMode(b.dataset.mode)));

function renderUser(user) {
  authForm.classList.add('hidden');
  $('#userPanel').classList.remove('hidden');
  $('#userGreeting').textContent = `Kamu login sebagai ${user.name} (${user.email}).`;
  $('#openAuth').textContent = 'ACCOUNT ↗';
}
function renderLoggedOut() {
  authForm.classList.remove('hidden');
  $('#userPanel').classList.add('hidden');
  $('#openAuth').innerHTML = 'LOGIN <span>↗</span>';
}
$('#logoutBtn').addEventListener('click', () => {
  token = ''; localStorage.removeItem('arga_token'); renderLoggedOut(); setMode('login');
  authStatus.textContent = 'Kamu sudah logout.';
});

authForm.addEventListener('submit', async e => {
  e.preventDefault();
  const data = Object.fromEntries(new FormData(authForm).entries());
  authStatus.textContent = 'Memproses...';
  try {
    const response = await fetch(`/api/${authMode}`, {
      method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(data)
    });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || 'Permintaan gagal.');
    token = result.token; localStorage.setItem('arga_token', token);
    authStatus.textContent = result.message;
    renderUser(result.user);
  } catch (err) { authStatus.textContent = err.message; }
});

async function checkSession() {
  if (!token) return;
  try {
    const r = await fetch('/api/me', {headers:{Authorization:`Bearer ${token}`}});
    const d = await r.json();
    if (!r.ok) throw new Error('Session expired');
    renderUser(d.user);
  } catch { token=''; localStorage.removeItem('arga_token'); renderLoggedOut(); }
}
checkSession();

$('#contactForm').addEventListener('submit', async e => {
  e.preventDefault();
  const form = e.currentTarget;
  const status = $('#contactStatus');
  status.textContent = 'Mengirim pesan...';
  const data = Object.fromEntries(new FormData(form).entries());
  try {
    const r = await fetch('/api/contact', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});
    const d = await r.json();
    if (!r.ok) throw new Error(d.error || 'Gagal mengirim pesan.');
    status.textContent = d.message; form.reset();
  } catch (err) { status.textContent = err.message; }
});

async function loadProjects() {
  try {
    const r = await fetch('/api/projects');
    if (!r.ok) return;
    const d = await r.json();
    if (!d.projects?.length) return;
    $('#projectGrid').innerHTML = d.projects.map((p,i) => `
      <article class="project-card">
        <img src="${escapeHtml(p.image_url || '')}" alt="${escapeHtml(p.title)}" loading="lazy">
        <div class="project-info">
          <small>${String(i+1).padStart(2,'0')} / PROJECT</small>
          <h3>${escapeHtml(p.title)}</h3>
          <p>${escapeHtml(p.description)}</p>
          ${p.project_url && p.project_url !== '#' ? `<a class="text-link" target="_blank" rel="noopener noreferrer" href="${escapeHtml(p.project_url)}">VIEW PROJECT ↗</a>` : ''}
        </div>
      </article>`).join('');
  } catch {}
}
function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}
loadProjects();

const observer = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.style.opacity = '1';
      entry.target.style.transform = 'translateY(0)';
      observer.unobserve(entry.target);
    }
  });
},{threshold:.12});
document.querySelectorAll('.skill-card,.project-card,.about-grid,.contact-panel').forEach(el => {
  el.style.opacity='0'; el.style.transform='translateY(22px)'; el.style.transition='opacity .7s ease, transform .7s ease';
  observer.observe(el);
});
