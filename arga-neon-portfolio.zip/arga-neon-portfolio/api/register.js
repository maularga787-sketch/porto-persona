const bcrypt = require('bcryptjs');
const { db, ensureTables } = require('./_db');
const { signToken } = require('./_auth');

module.exports = async (req, res) => {
  res.setHeader('Content-Type', 'application/json');
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method tidak diizinkan.' });
  try {
    const { name, email, password } = req.body || {};
    if (!name || !email || !password) return res.status(400).json({ error: 'Nama, email, dan password wajib diisi.' });
    if (String(name).trim().length < 2 || String(name).length > 100) return res.status(400).json({ error: 'Nama harus 2–100 karakter.' });
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(email))) return res.status(400).json({ error: 'Format email tidak valid.' });
    if (String(password).length < 8) return res.status(400).json({ error: 'Password minimal 8 karakter.' });
    const sql = db(); await ensureTables(sql);
    const normalizedEmail = String(email).trim().toLowerCase();
    const existing = await sql`SELECT id FROM users WHERE email = ${normalizedEmail} LIMIT 1`;
    if (existing.length) return res.status(409).json({ error: 'Email sudah terdaftar.' });
    const hash = await bcrypt.hash(String(password), 12);
    const rows = await sql`
      INSERT INTO users (name, email, password_hash)
      VALUES (${String(name).trim()}, ${normalizedEmail}, ${hash})
      RETURNING id, name, email
    `;
    const user = rows[0];
    return res.status(201).json({ message: 'Akun berhasil dibuat.', user, token: signToken(user) });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ error: 'Gagal membuat akun. Periksa konfigurasi database.' });
  }
};
