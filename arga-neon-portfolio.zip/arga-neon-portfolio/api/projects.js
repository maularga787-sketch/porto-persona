const { db, ensureTables } = require('./_db');
module.exports = async (req, res) => {
  res.setHeader('Content-Type', 'application/json');
  if (req.method !== 'GET') return res.status(405).json({ error: 'Method tidak diizinkan.' });
  try {
    const sql = db(); await ensureTables(sql);
    let rows = await sql`SELECT id, title, description, image_url, project_url, created_at FROM projects ORDER BY created_at DESC LIMIT 30`;
    if (!rows.length) {
      rows = [
        { id: 'demo-1', title: 'Neon Portfolio', description: 'Portfolio futuristik dengan antarmuka neon dan animasi.', image_url: 'https://images.unsplash.com/photo-1518770660439-4636190af475?w=900', project_url: '#' },
        { id: 'demo-2', title: 'Network Dashboard', description: 'Konsep dashboard pemantauan jaringan komputer.', image_url: 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=900', project_url: '#' },
        { id: 'demo-3', title: 'Creative Web UI', description: 'Eksplorasi desain antarmuka modern dan responsif.', image_url: 'https://images.unsplash.com/photo-1559028012-481c04fa702d?w=900', project_url: '#' }
      ];
    }
    return res.status(200).json({ projects: rows });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ error: 'Gagal mengambil proyek.' });
  }
};
