const bcrypt = require('bcryptjs');
const { db, ensureTables } = require('./_db');
const { signToken } = require('./_auth');

module.exports = async (req, res) => {
  res.setHeader('Content-Type', 'application/json');
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method tidak diizinkan.' });
  try {
    const { email, password } = req.body || {};
    if (!email || !password) return res.status(400).json({ error: 'Email dan password wajib diisi.' });
    const sql = db(); await ensureTables(sql);
    const normalizedEmail = String(email).trim().toLowerCase();
    const rows = await sql`SELECT id, name, email, password_hash FROM users WHERE email = ${normalizedEmail} LIMIT 1`;
    if (!rows.length || !(await bcrypt.compare(String(password), rows[0].password_hash))) {
      return res.status(401).json({ error: 'Email atau password salah.' });
    }
    const user = { id: rows[0].id, name: rows[0].name, email: rows[0].email };
    return res.status(200).json({ message: 'Login berhasil.', user, token: signToken(user) });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ error: 'Login gagal. Periksa konfigurasi database.' });
  }
};
