const { requireUser } = require('./_auth');
module.exports = (req, res) => {
  res.setHeader('Content-Type', 'application/json');
  if (req.method !== 'GET') return res.status(405).json({ error: 'Method tidak diizinkan.' });
  const user = requireUser(req);
  if (!user) return res.status(401).json({ error: 'Sesi tidak valid atau sudah kedaluwarsa.' });
  return res.status(200).json({ user });
};
