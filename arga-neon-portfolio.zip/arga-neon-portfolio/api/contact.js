const { db, ensureTables } = require('./_db');
module.exports = async (req, res) => {
  res.setHeader('Content-Type', 'application/json');
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method tidak diizinkan.' });
  try {
    const { name, email, message } = req.body || {};
    if (!name || !email || !message) return res.status(400).json({ error: 'Semua kolom wajib diisi.' });
    if (String(message).length > 5000) return res.status(400).json({ error: 'Pesan maksimal 5000 karakter.' });
    const sql = db(); await ensureTables(sql);
    await sql`INSERT INTO messages (name, email, message) VALUES (${String(name).trim()}, ${String(email).trim().toLowerCase()}, ${String(message).trim()})`;
    return res.status(201).json({ message: 'Pesan berhasil dikirim. Terima kasih!' });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ error: 'Pesan gagal disimpan. Periksa database.' });
  }
};
