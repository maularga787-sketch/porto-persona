const jwt = require('jsonwebtoken');

function signToken(user) {
  if (!process.env.JWT_SECRET) throw new Error('JWT_SECRET belum diatur.');
  return jwt.sign(
    { sub: String(user.id), email: user.email, name: user.name },
    process.env.JWT_SECRET,
    { expiresIn: '7d' }
  );
}

function requireUser(req) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : '';
  if (!token || !process.env.JWT_SECRET) return null;
  try { return jwt.verify(token, process.env.JWT_SECRET); }
  catch { return null; }
}
module.exports = { signToken, requireUser };
