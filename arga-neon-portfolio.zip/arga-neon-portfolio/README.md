# Arga Maulana — Neon Portfolio

Website portofolio futuristik dengan HTML/CSS/JS, Vercel Functions, Neon PostgreSQL, register/login, dan formulir kontak.

## 1. Kebutuhan
- Debian 13
- Node.js 20 atau lebih baru
- Akun GitHub
- Akun Vercel
- Database PostgreSQL Neon

## 2. Buat database Neon
1. Buat project di https://neon.tech/
2. Buka dashboard project → Connect.
3. Pilih connection string PostgreSQL.
4. Salin connection string. Jangan publikasikan string ini.

Tabel `users`, `messages`, dan `projects` dibuat otomatis oleh API saat pertama dipakai.

## 3. Instalasi Debian 13
Jalankan sebagai root atau tambahkan sudo bila memakai user biasa:

```bash
apt update
apt install -y curl git unzip
```

Instal Node.js 22 LTS (disarankan melalui NodeSource):
```bash
curl -fsSL https://deb.nodesource.com/setup_22.x | bash -
apt install -y nodejs
node -v
npm -v
```

Ekstrak ZIP, masuk folder proyek, lalu instal:
```bash
unzip arga-neon-portfolio.zip
cd arga-neon-portfolio
npm install
npm install -g vercel
```

## 4. Konfigurasi lokal
Buat file `.env.local`:
```bash
nano .env.local
```

Isi:
```env
DATABASE_URL=PASTE_NEON_CONNECTION_STRING_DI_SINI
JWT_SECRET=GANTI_DENGAN_SECRET_ACAK_PANJANG
ADMIN_EMAIL=emailkamu@example.com
```

Buat secret acak dengan:
```bash
openssl rand -hex 32
```
Salin hasilnya ke `JWT_SECRET`. Jangan upload `.env.local` ke GitHub.

Jalankan:
```bash
vercel dev
```
Buka alamat lokal yang ditampilkan (biasanya http://localhost:3000).

## 5. Deploy ke Vercel
Cara termudah:
1. Upload folder proyek ke repository GitHub milikmu.
2. Buka https://vercel.com/new
3. Import repository tersebut.
4. Framework preset: Other.
5. Root Directory: `./`
6. Build Command: kosongkan.
7. Output Directory: `public`
8. Install Command: `npm install`
9. Tambahkan Environment Variables:
   - `DATABASE_URL`
   - `JWT_SECRET`
   - `ADMIN_EMAIL`
10. Deploy.

Jika proyek Vercel `website-vercel` sudah ada dan ingin tetap menggunakan proyek/domain yang sama, hubungkan repository ini dari Settings → Git pada proyek tersebut, bukan membuat proyek baru.

## 6. Domain
Di proyek Vercel → Settings → Domains, pastikan `argamaulana.my.id` dan `www.argamaulana.my.id` terpasang pada proyek yang benar. Jangan ubah DNS yang sudah valid tanpa memeriksa instruksi DNS yang ditampilkan Vercel.

## 7. Mengubah foto profil
Ganti placeholder di `public/index.html` menjadi:
```html
<div class="profile-placeholder">
  <img src="/assets/profile.jpg" alt="Arga Maulana">
</div>
```
Upload foto milikmu ke `public/assets/profile.jpg`. Tambahkan CSS:
```css
.profile-placeholder img {
  width:100%; height:100%; object-fit:cover;
}
```

## 8. Mengisi proyek ke database
Contoh SQL di Neon SQL Editor:
```sql
INSERT INTO projects (title, description, image_url, project_url)
VALUES
('Website Portfolio', 'Website portofolio neon futuristik.', 'https://images.unsplash.com/photo-1518770660439-4636190af475?w=900', 'https://argamaulana.my.id'),
('MikroTik Simple Queue', 'Praktik manajemen bandwidth jaringan.', 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=900', 'https://example.com');
```
Proyek akan muncul melalui `/api/projects`.

## 9. Uji fitur
- Register: tombol LOGIN → REGISTER.
- Login: gunakan akun yang sudah didaftarkan.
- Kontak: isi formulir kontak; data masuk ke tabel `messages`.
- Proyek: data diambil dari tabel `projects`.

## Catatan keamanan
- Token login disimpan di localStorage pada contoh ini. Untuk aplikasi produksi dengan kebutuhan keamanan lebih tinggi, pertimbangkan cookie HttpOnly, CSRF protection, rate limiting, dan verifikasi email.
- API ini belum memiliki halaman admin untuk membaca pesan atau mengelola proyek. Data dapat diperiksa melalui Neon SQL Editor.
- `ADMIN_EMAIL` disiapkan sebagai konfigurasi untuk pengembangan lanjutan; belum digunakan sebagai hak akses admin pada kode saat ini.
- Jangan commit file `.env.local`, password, connection string, atau token GitHub.
- Ganti email dan informasi profil contoh dengan data yang benar.
